-- ====================================================================
-- COMPLETE DATABASE SCHEMA & DATA FOR SARVODAYA SHIKSHAN MANDAL, CHANDRAPUR
-- Target Domain: https://sarvodaya.drkrishnakaroo.com/
-- Target Hostinger Database: u855611336_Sarvodaya (MySQL / phpMyAdmin)
-- Generated on: 2026-09-12T12:22:50.735Z
--
-- INCLUDED TABLES:
-- 1. admins               - Administrative user accounts with bcrypt password hashing
-- 2. content_blocks       - All 69 rich content blocks (messages, history, vision, contacts, board)
-- 3. announcements        - Notices and news with PDF and image attachment support
-- 4. events               - Academic, cultural, and sports events calendar
-- 5. institutions         - Complete profiles and directory of all 11 schools and colleges
-- 6. careers              - Job openings, eligibility requirements, and recruitment advertisements
-- 7. job_applications     - Online applicant submissions, resumes, certificates, and tracking numbers
-- 8. inquiries            - Public contact and admission inquiries
-- 9. alumni_registrations - Alumni registration directory and member profiles
-- ====================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+05:30";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------------------
-- 1. TABLE: admins
-- Administrative user accounts with secure bcrypt password hashing
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(255) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` VARCHAR(50) DEFAULT 'admin',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 2. TABLE: content_blocks
-- All 69 rich content blocks (executive messages, history, vision, contact details, board member data, etc.)
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `content_blocks`;
CREATE TABLE `content_blocks` (
  `id` VARCHAR(255) NOT NULL PRIMARY KEY,
  `content` LONGTEXT,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 3. TABLE: announcements
-- Notices and news with support for PDF and image attachments
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `announcements`;
CREATE TABLE `announcements` (
  `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(500) NOT NULL,
  `content` TEXT,
  `date` VARCHAR(100),
  `is_new` TINYINT(1) DEFAULT 0,
  `display_order` INT DEFAULT 0,
  `attachmentUrl` TEXT,
  `attachmentOriginalName` VARCHAR(255),
  `attachmentType` VARCHAR(50),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 4. TABLE: events
-- Academic, cultural, and sports events calendar
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `date` VARCHAR(50),
  `month` VARCHAR(50),
  `title` VARCHAR(500),
  `location` VARCHAR(500),
  `display_order` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 5. TABLE: institutions
-- Complete profiles and directory of all 11 schools and colleges
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `institutions`;
CREATE TABLE `institutions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(500) NOT NULL,
  `type` VARCHAR(150),
  `description` TEXT,
  `image_url` TEXT,
  `link` VARCHAR(500),
  `display_order` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 6. TABLE: careers
-- Job openings, eligibility requirements, and recruitment advertisements
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `careers`;
CREATE TABLE `careers` (
  `id` VARCHAR(255) NOT NULL PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `department` VARCHAR(150),
  `location` VARCHAR(150),
  `type` VARCHAR(50),
  `description` TEXT,
  `requirements` TEXT,
  `advertisementUrl` TEXT,
  `advertisementOriginalName` VARCHAR(255),
  `advertisementType` VARCHAR(50),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 7. TABLE: job_applications
-- Online applicant submissions, resumes, certificates, and application tracking numbers
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `job_applications`;
CREATE TABLE `job_applications` (
  `id` VARCHAR(255) NOT NULL PRIMARY KEY,
  `applicationNumber` VARCHAR(100),
  `careerId` VARCHAR(255),
  `jobTitle` VARCHAR(255),
  `name` VARCHAR(200) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(50),
  `coverLetter` TEXT,
  `resumeUrl` VARCHAR(1000),
  `resumeOriginalName` VARCHAR(255),
  `photoUrl` TEXT,
  `documentsUrl` TEXT,
  `details` LONGTEXT,
  `status` VARCHAR(50) DEFAULT 'new',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 8. TABLE: inquiries
-- Public contact and admission inquiries
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `inquiries`;
CREATE TABLE `inquiries` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(50),
  `program` VARCHAR(255),
  `message` TEXT,
  `status` VARCHAR(50) DEFAULT 'new',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------------------
-- 9. TABLE: alumni_registrations
-- Alumni registration directory and member profiles
-- --------------------------------------------------------------------
DROP TABLE IF EXISTS `alumni_registrations`;
CREATE TABLE `alumni_registrations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `fullName` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(50),
  `dob` VARCHAR(50),
  `gender` VARCHAR(50),
  `institution` VARCHAR(255),
  `passingYear` VARCHAR(50),
  `degree` VARCHAR(255),
  `profession` VARCHAR(255),
  `company` VARCHAR(255),
  `designation` VARCHAR(255),
  `location` VARCHAR(255),
  `linkedin` VARCHAR(500),
  `message` TEXT,
  `photoUrl` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ====================================================================
-- SEED DATA FOR ALL 9 TABLES
-- ====================================================================

-- 1. ADMIN ACCOUNTS (bcrypt hashes)
-- Username: 'admin'        -> Password: 'admin' (also accepts 'Pass')
-- Username: 'admin@ssm.edu' -> Password: 'password123'
INSERT INTO `admins` (`id`, `email`, `password_hash`, `role`) VALUES
(1, 'admin', '$2y$10$.w6MlMpEmvjO6SIV2l9vmuu98ZhBhAzpsKufbFN77s1L/hrlb6fcu', 'master'),
(2, 'admin@ssm.edu', '$2y$10$Iov2i2DmfZI5Aqo9p32mQu3q4m1wO2mq/ZErca8OgHdp78HbPL4OG', 'master');

-- 2. CONTENT BLOCKS (Total: 69 items)
INSERT INTO `content_blocks` (`id`, `content`) VALUES
('Org_Name', 'सर्वोदय शिक्षण मंडळ, चंद्रपूर'),
('Org_Subtitle', 'Central India\'s Premier Educational Network • रजि.नं F-09 (C)'),
('Org_RegNo', 'रजि.नं F-09 (C)'),
('President_Name', 'मा. श्री. अरविंद नामदेवराव पोरेड्डीवार'),
('President_Title', 'अध्यक्ष (President)'),
('WorkingPresident_Name', 'मा. श्री. किशोर गजानन जोरगेवार'),
('WorkingPresident_Title', 'कार्यकारी अध्यक्ष (Executive President)'),
('Secretary_Name', 'मा. श्री. प्रशांत शांताराम पोटदुखे'),
('Secretary_Title', 'सचिव (Secretary)'),
('VicePresident1_Name', 'मा. श्री. सुदर्शन भगवानराव निमकर'),
('VicePresident1_Title', 'उपाध्यक्ष (Vice President)'),
('VicePresident2_Name', 'मा. सौ. सगुणा पेंन्टाजी तलांडी'),
('VicePresident2_Title', 'उपाध्यक्षा (Vice President)'),
('Leader1_Text_En', 'Welcome to Sarvodaya Shikshan Mandal.\n\nEducation is not merely the accumulation of facts; it is the preparation for life itself. Since our inception, we have been steadfast in our mission to bring the light of higher education to the most remote and underserved regions of Chandrapur and Gadchiroli.\n\nOur philosophy of \'Sarvodaya\' means the rise and awakening of everyone. We believe that true progress of our nation lies in empowering the marginalized, the rural, and the tribal youth. We strive to provide an environment where traditional cultural values harmonize perfectly with modern scientific temper, creating not just successful professionals, but morally upright citizens.\n\nI invite you to be a part of this academic revolution. Together, let us shape a brighter, more equitable future.'),
('Leader1_Text_Mr', 'सर्वोदय शिक्षण मंडळात आपले स्वागत आहे.\n\nशिक्षण म्हणजे केवळ माहिती गोळा करणे नव्हे, तर ती जीवनाची एक पूर्वतयारी आहे. आमच्या स्थापनेपासूनच, चंद्रपूर आणि गडचिरोली सारख्या अतिदुर्गम आणि वंचित भागात उच्च शिक्षणाची ज्ञानगंगा पोहोचवण्याच्या ध्येयाशी आम्ही कटिबद्ध आहोत.\n\n\'सर्वोदय\' या आमच्या तत्त्वज्ञानाचा अर्थ आहे- सर्वांचा उदय आणि सर्वांचा विकास. आमचा असा ठाम विश्वास आहे की, आपल्या देशाची खरी प्रगती तळागाळातील, ग्रामीण आणि आदिवासी तरुणांच्या सक्षमीकरणातच दडलेली आहे. आधुनिक विज्ञान आणि आपली पारंपारिक सांस्कृतिक मूल्ये यांचा सुरेख संगम साधून केवळ यशस्वी व्यावसायिकच नव्हे, तर चारित्र्यवान आणि नीतिमान नागरिक घडवण्यासाठी आम्ही नेहमी प्रयत्नशील आहोत.\n\nमी आपणा सर्वांना या शैक्षणिक क्रांतीचा एक भाग होण्यासाठी आमंत्रित करतो. चला, एकत्र मिळून एका उज्ज्वल आणि समतापूर्ण भविष्याची निर्मिती करूया.'),
('Leader1_Quote_En', 'To realize the vision of \'Sarvodaya\' — the upliftment of all through knowledge, character, and ethical values — and empower rural and tribal youth to become leaders in nation-building.'),
('Leader1_Quote_Mr', 'ज्ञान, शील आणि संस्कारांच्या माध्यमातून सर्वोदयाचे स्वप्न साकार करणे व ग्रामीण-दुर्गम भागातील विद्यार्थ्यांना राष्ट्रउभारणीत अग्रेसर करणे हेच आमचे आद्य कर्तव्य आहे.'),
('President_Quote_En', 'To realize the vision of \'Sarvodaya\' — the upliftment of all through knowledge, character, and ethical values — and empower rural and tribal youth to become leaders in nation-building.'),
('President_Quote_Mr', 'ज्ञान, शील आणि संस्कारांच्या माध्यमातून सर्वोदयाचे स्वप्न साकार करणे व ग्रामीण-दुर्गम भागातील विद्यार्थ्यांना राष्ट्रउभारणीत अग्रेसर करणे हेच आमचे आद्य कर्तव्य आहे.'),
('President_Text_En', 'Welcome to Sarvodaya Shikshan Mandal.\n\nEducation is not merely the accumulation of facts; it is the preparation for life itself. Since our inception, we have been steadfast in our mission to bring the light of higher education to the most remote and underserved regions of Chandrapur and Gadchiroli.\n\nOur philosophy of \'Sarvodaya\' means the rise and awakening of everyone. We believe that true progress of our nation lies in empowering the marginalized, the rural, and the tribal youth. We strive to provide an environment where traditional cultural values harmonize perfectly with modern scientific temper, creating not just successful professionals, but morally upright citizens.\n\nI invite you to be a part of this academic revolution. Together, let us shape a brighter, more equitable future.'),
('President_Text_Mr', 'सर्वोदय शिक्षण मंडळात आपले स्वागत आहे.\n\nशिक्षण म्हणजे केवळ माहिती गोळा करणे नव्हे, तर ती जीवनाची एक पूर्वतयारी आहे. आमच्या स्थापनेपासूनच, चंद्रपूर आणि गडचिरोली सारख्या अतिदुर्गम आणि वंचित भागात उच्च शिक्षणाची ज्ञानगंगा पोहोचवण्याच्या ध्येयाशी आम्ही कटिबद्ध आहोत.\n\n\'सर्वोदय\' या आमच्या तत्त्वज्ञानाचा अर्थ आहे- सर्वांचा उदय आणि सर्वांचा विकास. आमचा असा ठाम विश्वास आहे की, आपल्या देशाची खरी प्रगती तळागाळातील, ग्रामीण आणि आदिवासी तरुणांच्या सक्षमीकरणातच दडलेली आहे. आधुनिक विज्ञान आणि आपली पारंपारिक सांस्कृतिक मूल्ये यांचा सुरेख संगम साधून केवळ यशस्वी व्यावसायिकच नव्हे, तर चारित्र्यवान आणि नीतिमान नागरिक घडवण्यासाठी आम्ही नेहमी प्रयत्नशील आहोत.\n\nमी आपणा सर्वांना या शैक्षणिक क्रांतीचा एक भाग होण्यासाठी आमंत्रित करतो. चला, एकत्र मिळून एका उज्ज्वल आणि समतापूर्ण भविष्याची निर्मिती करूया.'),
('Leader2_Text_En', 'Greetings to all,\n\nAs the Executive President of Sarvodaya Shikshan Mandal, my primary focus is on ensuring that our visionary goals are met with robust execution. Establishing state-of-the-art facilities across our 11 institutions and ensuring uninterrupted, high-quality education for over 22,000 students is a monumental responsibility.\n\nWe are constantly upgrading our technological landscape, modernizing our laboratories, and enriching our libraries. Our administrative and teaching staff work tirelessly to create a seamless, disciplined, and nurturing environment for every student who steps into our campuses.\n\nWe remain committed to transparency, innovation, and an unwavering focus on student welfare.'),
('Leader2_Text_Mr', 'सर्वांना नमस्कार,\n\nसर्वोदय शिक्षण मंडळाचा कार्याध्यक्ष या नात्याने, संस्थेच्या दूरदृष्टीला योग्य दिशा देणे आणि तिची प्रभावी अंमलबजावणी करणे हे माझे प्रमुख उद्दिष्ट आहे. आमच्या ११ शैक्षणिक संस्थांमध्ये अद्ययावत सुविधा निर्माण करणे आणि २२,००० हून अधिक विद्यार्थ्यांना विनाअडथळा दर्जेदार शिक्षण उपलब्ध करून देणे ही एक मोठी जबाबदारी आहे.\n\nआम्ही सातत्याने तंत्रज्ञान अद्ययावत करत आहोत, प्रयोगशाळांचे आधुनिकीकरण करत आहोत आणि ग्रंथालये समृद्ध करत आहोत. आमचे प्रशासकीय आणि शिक्षक कर्मचारी प्रत्येक विद्यार्थ्याला एक शिस्तबद्ध, पोषक आणि सुरक्षित वातावरण प्रदान करण्यासाठी अथक परिश्रम करत आहेत.\n\nपारदर्शकता, नाविन्य आणि विद्यार्थ्यांच्या कल्याणासाठी आम्ही सदैव बांधील आहोत.'),
('Leader2_Quote_En', 'Execution is the bridge between vision and reality. We are dedicated to translating our educational ideals into tangible, transformative infrastructure and academic excellence.'),
('Leader2_Quote_Mr', 'अंमलबजावणी हा ध्येय आणि वास्तवातील दुवा आहे. आपले शैक्षणिक आदर्श उत्कृष्ट पायाभूत सुविधा आणि गुणवत्तेत रूपांतरित करण्यासाठी आम्ही कटिबद्ध आहोत.'),
('WorkingPresident_Quote_En', 'Execution is the bridge between vision and reality. We are dedicated to translating our educational ideals into tangible, transformative infrastructure and academic excellence.'),
('WorkingPresident_Quote_Mr', 'अंमलबजावणी हा ध्येय आणि वास्तवातील दुवा आहे. आपले शैक्षणिक आदर्श उत्कृष्ट पायाभूत सुविधा आणि गुणवत्तेत रूपांतरित करण्यासाठी आम्ही कटिबद्ध आहोत.'),
('WorkingPresident_Text_En', 'Greetings to all,\n\nAs the Executive President of Sarvodaya Shikshan Mandal, my primary focus is on ensuring that our visionary goals are met with robust execution. Establishing state-of-the-art facilities across our 11 institutions and ensuring uninterrupted, high-quality education for over 22,000 students is a monumental responsibility.\n\nWe are constantly upgrading our technological landscape, modernizing our laboratories, and enriching our libraries. Our administrative and teaching staff work tirelessly to create a seamless, disciplined, and nurturing environment for every student who steps into our campuses.\n\nWe remain committed to transparency, innovation, and an unwavering focus on student welfare.'),
('WorkingPresident_Text_Mr', 'सर्वांना नमस्कार,\n\nसर्वोदय शिक्षण मंडळाचा कार्याध्यक्ष या नात्याने, संस्थेच्या दूरदृष्टीला योग्य दिशा देणे आणि तिची प्रभावी अंमलबजावणी करणे हे माझे प्रमुख उद्दिष्ट आहे. आमच्या ११ शैक्षणिक संस्थांमध्ये अद्ययावत सुविधा निर्माण करणे आणि २२,००० हून अधिक विद्यार्थ्यांना विनाअडथळा दर्जेदार शिक्षण उपलब्ध करून देणे ही एक मोठी जबाबदारी आहे.\n\nआम्ही सातत्याने तंत्रज्ञान अद्ययावत करत आहोत, प्रयोगशाळांचे आधुनिकीकरण करत आहोत आणि ग्रंथालये समृद्ध करत आहोत. आमचे प्रशासकीय आणि शिक्षक कर्मचारी प्रत्येक विद्यार्थ्याला एक शिस्तबद्ध, पोषक आणि सुरक्षित वातावरण प्रदान करण्यासाठी अथक परिश्रम करत आहेत.\n\nपारदर्शकता, नाविन्य आणि विद्यार्थ्यांच्या कल्याणासाठी आम्ही सदैव बांधील आहोत.'),
('Leader3_Text_En', 'Hello,\n\nOur commitment as an institution is to ensure that geography never dictates destiny. We are incredibly proud of the fact that Sarvodaya Shikshan Mandal has built strong educational ecosystems in the most difficult terrains of the region.\n\nBy providing superior guidance, robust academic frameworks, and continuous mentorship, we are helping students from the heartlands dream big and achieve even bigger. Our success is reflected in the eyes of every first-generation learner who graduates from our institutions.'),
('Leader3_Text_Mr', 'नमस्कार,\n\nएक संस्था म्हणून आमची ही बांधिलकी आहे की भौगोलिक परिस्थितीमुळे कोणाचेही भवितव्य थांबू नये. सर्वोदय शिक्षण मंडळाने या परिसरातील अतिशय दुर्गम भागातही सक्षम शैक्षणिक परिसंस्था निर्माण केल्या आहेत, याचा आम्हाला सार्थ अभिमान आहे.\n\nउत्कृष्ट मार्गदर्शन, भक्कम शैक्षणिक आराखडा आणि सातत्यपूर्ण मार्गदर्शनातून आम्ही तळागाळातील विद्यार्थ्यांना मोठी स्वप्ने पाहण्यास आणि ती पूर्ण करण्यास मदत करत आहोत. आमच्या संस्थेतून पदवी प्राप्त करणाऱ्या प्रत्येक पहिल्या पिढीतील विद्यार्थ्याच्या डोळ्यांत आमचे यश प्रतिबिंबित होते.'),
('Leader3_Quote_En', 'True empowerment comes when education reaches the last mile. Our focus remains on breaking geographical barriers to deliver uncompromising quality.'),
('Leader3_Quote_Mr', 'खरे सक्षमीकरण तेव्हाच होते जेव्हा शिक्षण शेवटच्या घटकापर्यंत पोहोचते. भौगोलिक अडथळे दूर करून उत्कृष्ट दर्जाचे शिक्षण देण्यावर आमचा भर आहे.'),
('Leader4_Text_En', 'Greetings,\n\nEducation is the most powerful catalyst for social equity. At Sarvodaya Shikshan Mandal, we place a special emphasis on the education and holistic development of young women and marginalized communities.\n\nWe have instituted numerous support systems to ensure a safe, encouraging, and highly productive environment for girls. Witnessing our female students excel in academics, sports, and leadership roles is the most fulfilling aspect of our mission. When you educate a woman, you elevate an entire generation.'),
('Leader4_Text_Mr', 'नमस्कार,\n\nसामाजिक समतेसाठी शिक्षण हा सर्वात प्रभावी मार्ग आहे. सर्वोदय शिक्षण मंडळात आम्ही तरुणी आणि उपेक्षित घटकांच्या शिक्षणावर व त्यांच्या सर्वांगीण विकासावर विशेष भर देतो.\n\nमुलींसाठी एक सुरक्षित, प्रेरणादायी आणि अत्यंत पोषक वातावरण सुनिश्चित करण्यासाठी आम्ही अनेक आधारभूत यंत्रणा कार्यान्वित केल्या आहेत. आमच्या विद्यार्थिनींना शिक्षण, खेळ आणि नेतृत्वात चमकदार कामगिरी करताना पाहणे हा आमच्या ध्येयाचा सर्वात समाधानकारक भाग आहे. जेव्हा तुम्ही एका मुलीला शिक्षित करता, तेव्हा तुम्ही संपूर्ण पिढीला उन्नत करता.'),
('Leader4_Quote_En', 'Empowering women and marginalized communities through education is not just our goal; it is the very foundation of our social responsibility.'),
('Leader4_Quote_Mr', 'शिक्षणातून महिला आणि उपेक्षित घटकांचे सक्षमीकरण हे केवळ आमचे ध्येय नाही, तर ती आमच्या सामाजिक बांधिलकीची पायाभरणी आहे.'),
('Leader5_Text_En', 'Welcome,\n\nAs the Secretary of the Mandal, managing the dynamic needs of multiple colleges and schools requires precision, foresight, and a deep understanding of evolving educational paradigms. Our goal is to maintain a perfect balance between rigorous academic standards and compassionate administration.\n\nWe have streamlined our governance models, digitized our workflows, and ensured that every faculty member is supported in their pursuit of teaching excellence. The synergy between our management, staff, and students is the driving force behind the unprecedented success and growth of our Mandal.'),
('Leader5_Text_Mr', 'स्वागत आहे,\n\nमंडळाचे सचिव म्हणून, अनेक महाविद्यालये आणि शाळांच्या गरजांचे व्यवस्थापन करण्यासाठी अचूकता, दूरदृष्टी आणि बदलत्या शैक्षणिक प्रवाहांची सखोल जाण असणे आवश्यक आहे. कडक शैक्षणिक मानके आणि संवेदनशील प्रशासन यांच्यात योग्य समतोल राखणे हे आमचे ध्येय आहे.\n\nआम्ही आमची प्रशासकीय कार्यपद्धती सुलभ केली आहे, कामाचे संगणकीकरण केले आहे आणि प्रत्येक शिक्षकाला त्यांच्या उत्कृष्ट अध्यापनात मदत मिळेल याची खात्री केली आहे. आमचे व्यवस्थापन, कर्मचारी आणि विद्यार्थी यांच्यातील समन्वय हीच आमच्या मंडळाच्या अभूतपूर्व यशाची आणि प्रगतीची प्रेरक शक्ती आहे.'),
('Leader5_Quote_En', 'Administrative efficiency and academic brilliance must go hand-in-hand to forge institutions of monumental legacy.'),
('Leader5_Quote_Mr', 'प्रचंड वारसा लाभलेल्या संस्थांची उभारणी करण्यासाठी प्रशासकीय कार्यक्षमता आणि शैक्षणिक बुद्धिमत्ता यांची सांगड घालणे आवश्यक आहे.'),
('Secretary_Quote_En', 'Administrative efficiency and academic brilliance must go hand-in-hand to forge institutions of monumental legacy.'),
('Secretary_Quote_Mr', 'प्रचंड वारसा लाभलेल्या संस्थांची उभारणी करण्यासाठी प्रशासकीय कार्यक्षमता आणि शैक्षणिक बुद्धिमत्ता यांची सांगड घालणे आवश्यक आहे.'),
('Secretary_Text_En', 'Welcome,\n\nAs the Secretary of the Mandal, managing the dynamic needs of multiple colleges and schools requires precision, foresight, and a deep understanding of evolving educational paradigms. Our goal is to maintain a perfect balance between rigorous academic standards and compassionate administration.\n\nWe have streamlined our governance models, digitized our workflows, and ensured that every faculty member is supported in their pursuit of teaching excellence. The synergy between our management, staff, and students is the driving force behind the unprecedented success and growth of our Mandal.'),
('Secretary_Text_Mr', 'स्वागत आहे,\n\nमंडळाचे सचिव म्हणून, अनेक महाविद्यालये आणि शाळांच्या गरजांचे व्यवस्थापन करण्यासाठी अचूकता, दूरदृष्टी आणि बदलत्या शैक्षणिक प्रवाहांची सखोल जाण असणे आवश्यक आहे. कडक शैक्षणिक मानके आणि संवेदनशील प्रशासन यांच्यात योग्य समतोल राखणे हे आमचे ध्येय आहे.\n\nआम्ही आमची प्रशासकीय कार्यपद्धती सुलभ केली आहे, कामाचे संगणकीकरण केले आहे आणि प्रत्येक शिक्षकाला त्यांच्या उत्कृष्ट अध्यापनात मदत मिळेल याची खात्री केली आहे. आमचे व्यवस्थापन, कर्मचारी आणि विद्यार्थी यांच्यातील समन्वय हीच आमच्या मंडळाच्या अभूतपूर्व यशाची आणि प्रगतीची प्रेरक शक्ती आहे.'),
('Leader6_Text_En', 'Greetings,\n\nIn a rapidly changing world, our pedagogical approaches cannot remain static. As Joint Secretary, I am deeply invested in introducing modern methodologies, skill-based training, and research-oriented thinking into our curriculums.\n\nWe want our students to not only be highly employable but to be creators, thinkers, and innovators. We are constantly expanding our horizons, bringing in industry experts, and fostering an environment where curiosity is celebrated and intellect is sharpened.'),
('Leader6_Text_Mr', 'नमस्कार,\n\nवेगाने बदलणाऱ्या जगात, आपल्या अध्यापनाच्या पद्धती स्थिर राहू शकत नाहीत. सहसचिव या नात्याने, आपल्या अभ्यासक्रमात आधुनिक पद्धती, कौशल्य-आधारित प्रशिक्षण आणि संशोधन-केंद्रीत विचारांचा समावेश करण्यासाठी मी विशेष लक्ष देत आहे.\n\nआमचे विद्यार्थी केवळ नोकरीसाठी पात्र न राहता ते निर्माते, विचारवंत आणि संशोधक व्हावेत अशी आमची इच्छा आहे. आम्ही सातत्याने आमच्या कक्षा रुंदावत आहोत, उद्योग तज्ज्ञांना आमंत्रित करत आहोत आणि असे वातावरण निर्माण करत आहोत जिथे विद्यार्थ्यांच्या कुतूहलाला चालना मिळेल आणि बुद्धिमत्तेला धार येईल.'),
('Leader6_Quote_En', 'Innovation in teaching and adaptability to modern global challenges define the future of our educational endeavors.'),
('Leader6_Quote_Mr', 'अध्यापनातील नाविन्य आणि आधुनिक जागतिक आव्हानांना सामोरे जाण्याची क्षमता हेच आपल्या शैक्षणिक भविष्याची दिशा ठरवतात.'),
('Leader7_Text_En', 'Hello,\n\nAt Sarvodaya Shikshan Mandal, every resource is mobilized with absolute integrity and directed purely toward the betterment of our students. As Treasurer, maintaining financial discipline and transparency is paramount.\n\nOur sustainable financial practices ensure that despite minimal fees, we provide maximum infrastructure, excellent faculty, and outstanding resources. We have always prioritized long-term institutional growth over short-term gains, ensuring a stable and continuously flourishing educational sanctuary for generations to come.'),
('Leader7_Text_Mr', 'नमस्कार,\n\nसर्वोदय शिक्षण मंडळात, प्रत्येक संसाधनाचा वापर अत्यंत सचोटीने आणि केवळ विद्यार्थ्यांच्या भल्यासाठी केला जातो. कोषाध्यक्ष म्हणून, आर्थिक शिस्त आणि पारदर्शकता राखणे ही माझी सर्वोच्च प्राथमिकता आहे.\n\nआमच्या शाश्वत आर्थिक धोरणांमुळेच, अतिशय कमी शुल्कातही आम्ही अद्ययावत पायाभूत सुविधा, उत्कृष्ट शिक्षक आणि दर्जेदार संसाधने पुरवू शकतो. आम्ही अल्पकालीन फायद्यांपेक्षा संस्थेच्या दीर्घकालीन प्रगतीला नेहमीच प्राधान्य दिले आहे, ज्यामुळे येणाऱ्या अनेक पिढ्यांसाठी एक स्थिर आणि सातत्याने विकसित होणारे शैक्षणिक संकुल उभे राहिले आहे.'),
('Leader7_Quote_En', 'Financial discipline ensures that our core mission of providing affordable, world-class education remains perpetually sustainable.'),
('Leader7_Quote_Mr', 'आर्थिक शिस्त हे सुनिश्चित करते की, परवडणारे व जागतिक दर्जाचे शिक्षण देण्याचे आमचे मुख्य ध्येय कायमस्वरूपी शाश्वत राहील.'),
('Leader8_Text_En', 'As a member of the Board of Directors, my role is to bring diverse perspectives to the table and ensure that every policy drafted serves the best interests of the student body. The strength of Sarvodaya lies in its unity and shared vision. We are a family bound by the sacred duty of imparting knowledge.'),
('Leader8_Text_Mr', 'संचालक मंडळाचा सदस्य म्हणून, विविध दृष्टिकोन मांडणे आणि तयार केलेले प्रत्येक धोरण विद्यार्थ्यांच्या हिताचे असेल याची खात्री करणे ही माझी भूमिका आहे. सर्वोदयाची ताकद त्याच्या एकतेत आणि समान ध्येयात दडलेली आहे. ज्ञानदानाचे पवित्र कर्तव्य पार पाडण्यासाठी बांधलेले आम्ही सर्व एका कुटुंबासारखे आहोत.'),
('Leader8_Quote_En', 'Collective wisdom and democratic decision-making form the bedrock of our robust institutional governance.'),
('Leader8_Quote_Mr', 'सामूहिक शहाणपण आणि लोकशाही निर्णय प्रक्रिया हा आमच्या भक्कम संस्थात्मक कारभाराचा पाया आहे.'),
('Leader9_Text_En', 'Serving on this esteemed board is an honor and a profound responsibility. I work closely with my colleagues to ensure that the ethos of our founders is never diluted. From campus infrastructure to community outreach, we ensure Sarvodaya remains a beacon of hope for the region.'),
('Leader9_Text_Mr', 'या सन्माननीय मंडळावर काम करणे हा माझा मोठा बहुमान आणि तितकीच मोठी जबाबदारी आहे. आमच्या संस्थापकांची तत्त्वे कधीही ढळू नयेत यासाठी मी माझ्या सहकाऱ्यांसोबत मिळून काम करतो. परिसरातील पायाभूत सुविधांपासून ते समाजोपयोगी कार्यापर्यंत, सर्वोदय या भागातील आशेचा किरण राहील याची आम्ही खात्री करतो.'),
('Leader9_Quote_En', 'Education is a collective community effort, and we stand together to uphold its highest standards.'),
('Leader9_Quote_Mr', 'शिक्षण हा एक सामूहिक सामाजिक प्रयत्न आहे आणि त्याचे सर्वोच्च मापदंड टिकवून ठेवण्यासाठी आम्ही एकत्र उभे आहोत.'),
('Leader10_Text_En', 'I believe that strong institutions are built on strong foundations. As a board member, I actively support initiatives that bridge the gap between traditional wisdom and modern professional requirements. Our commitment is unwavering, and our journey towards excellence is continuous.'),
('Leader10_Text_Mr', 'माझा विश्वास आहे की मजबूत संस्था या भक्कम पायावरच उभ्या राहतात. एक संचालक या नात्याने, पारंपारिक शहाणपण आणि आधुनिक व्यावसायिक गरजा यामधील दरी कमी करणाऱ्या उपक्रमांना मी सक्रिय पाठिंबा देतो. आमची बांधिलकी अढळ आहे आणि उत्कृष्टतेचा आमचा प्रवास निरंतर चालू राहील.'),
('Leader10_Quote_En', 'Preserving our rich heritage while aggressively pursuing academic modernization is our collective promise.'),
('Leader10_Quote_Mr', 'आपल्या समृद्ध वारशाचे जतन करत शैक्षणिक आधुनिकीकरणाचा ध्यास घेणे हे आमचे सामूहिक वचन आहे.'),
('Leader11_Text_En', 'My vision aligned with the Mandal is very simple: no talent should go to waste due to a lack of resources or guidance. By actively participating in the board\'s strategic decisions, I strive to make sure that our colleges remain student-centric, progressive, and deeply rooted in moral values.'),
('Leader11_Text_Mr', 'मंडळाच्या ध्येयाशी सुसंगत असा माझा दृष्टिकोन अतिशय सोपा आहे: संसाधने किंवा मार्गदर्शनाच्या अभावामुळे कोणत्याही विद्यार्थ्याचे टॅलेंट वाया जाऊ नये. मंडळाच्या धोरणात्मक निर्णयांमध्ये सक्रिय सहभाग घेऊन, आमची महाविद्यालये नेहमी विद्यार्थी-केंद्रित, पुरोगामी आणि नैतिक मूल्यांची रुजवणूक करणारी राहतील यासाठी मी सतत प्रयत्नशील असतो.'),
('Leader11_Quote_En', 'Every student who walks through our gates is a seed of the future. It is our duty to provide the fertile soil they need to grow.'),
('Leader11_Quote_Mr', 'आमच्या संस्थेत प्रवेश घेणारा प्रत्येक विद्यार्थी हे भविष्याचे बीज आहे. त्यांना वाढण्यासाठी आवश्यक असलेली सुपीक जमीन उपलब्ध करून देणे हे आमचे कर्तव्य आहे.');

-- 3. ANNOUNCEMENTS (Total: 4 notices)
INSERT INTO `announcements` (`id`, `title`, `content`, `date`, `is_new`, `display_order`, `attachmentUrl`, `attachmentOriginalName`, `attachmentType`) VALUES
(1, 'शैक्षणिक वर्ष २०२६-२७ प्रवेश प्रक्रिया सुरू (Admissions Open 2026-27)', 'सर्वोदय शिक्षण मंडळाच्या सर्व शाळा, कनिष्ठ व वरिष्ठ महाविद्यालयांमध्ये नवीन शैक्षणिक सत्रासाठी प्रवेश प्रक्रिया सुरू झाली आहे. इच्छुक विद्यार्थ्यांनी कार्यालयाशी संपर्क साधावा.', '2026-09-01', 1, 1, NULL, NULL, 'pdf'),
(2, 'गोंडवाना विद्यापीठ पदवी व पदव्युत्तर परीक्षा वेळापत्रक जाहीर', 'गोंडवाना विद्यापीठ, गडचिरोली अंतर्गत उन्हाळी/हिवाळी सत्राच्या विविध परीक्षांचे वेळापत्रक महाविद्यालयाच्या सूचना फलकावर प्रसिद्ध करण्यात आले आहे.', '2026-09-05', 1, 2, NULL, NULL, 'pdf'),
(3, 'सर्वोदय शिक्षण मंडळ अंतर्गत सहाय्यक प्राध्यापक व प्रशासकीय पदभरती जाहिरात', 'सरदार पटेल महाविद्यालय व इतर शाखांसाठी सहाय्यक प्राध्यापक व प्रशासकीय पदांसाठी अर्ज मागविण्यात येत आहेत. तपशील करिअर विभागात उपलब्ध आहे.', '2026-09-10', 1, 3, NULL, NULL, 'pdf'),
(1789199010763, 'Test from script', 'hello', '2026', 0, 0, NULL, NULL, 'image');

-- 4. EVENTS CALENDAR (Total: 4 events)
INSERT INTO `events` (`id`, `date`, `month`, `title`, `location`, `display_order`) VALUES
(1, '15', 'APR', 'वार्षिक राज्यस्तरीय विज्ञान व तंत्रज्ञान प्रदर्शन (Annual State-Level Science & Tech Exhibition)', 'सरदार पटेल महाविद्यालय सभागृह, चंद्रपूर (Central Campus Auditorium)', 1),
(2, '28', 'FEB', 'राष्ट्रीय विज्ञान दिन व्याख्यान व कार्यशाळा (National Science Day Lecture & Workshop)', 'एसपीएम सायन्स कॉम्प्लेक्स, चंद्रपूर', 2),
(3, '12', 'JAN', 'राष्ट्रीय युवा दिन व स्वामी विवेकानंद जयंती महोत्सव (National Youth Day Celebration)', 'सर्वोदय शिक्षण मंडळ मुख्य प्रांगण', 3),
(4, '15', 'AUG', 'स्वातंत्र्य दिन ध्वजारोहण व गुणवंत विद्यार्थी सत्कार सोहळा', 'क्रीडा संकुल, सरदार पटेल महाविद्यालय', 4);

-- 5. INSTITUTIONS (Total: 11 institutions)
INSERT INTO `institutions` (`id`, `name`, `type`, `description`, `image_url`, `link`, `display_order`) VALUES
(1, 'सरदार पटेल महाविद्यालय, चंद्रपूर', 'Senior College & PG Research', 'Premier multi-faculty post-graduate and research college. Principal: डॉ. पी. एम. काटकर | Contact: 9422906289 | Email: chdspm@gmail.com', 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=800&q=80', 'https://spm.ac.in', 1),
(2, 'एस. आर. एम. महाविद्यालय सोशल वर्क पडोली चंद्रपूर', 'Social Work College', 'Professional social work college (BSW/MSW). Principal: डॉ. ममता ठाकूरवार | Contact: 9011378429 | Email: Srmcollege1988@gmail.com', 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80', 'https://srmcsw.edu.in', 2),
(3, 'शांताबाई पोटदुखे विधी महाविद्यालय, चंद्रपूर', 'Law College', 'Eminent legal education college affiliated to Gondwana University. Principal: डॉ. पूर्णेंदू कुमार कार | Contact: 9423416288 | Email: principalspcl@gmail.com', 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=800&q=80', 'https://spclchandrapur.org', 3),
(4, 'शंकरराव बेझलवार कला वाणिज्य महाविद्यालय, अहेरी', 'Arts & Commerce College', 'Arts & Commerce college empowering youth in Aheri region. Principal: डॉ. विजय सोमकुंवर | Contact: 9960429238 | Email: sbcollegeaheri@gmail.com', 'https://images.unsplash.com/photo-1592280771190-3e2e4d571952?auto=format&fit=crop&w=800&q=80', '#', 4),
(5, 'सौ. लिना किशोर मामीडवार इन्स्टिट्यूट ऑफ मॅनेजमेंट स्टडीज ॲण्ड रिसर्च कोसारा चंद्रपूर', 'Management & Research (MBA/MCA)', 'Premier management institute offering MBA programs. Principal: डॉ. जयेश चक्रवर्ती | Contact: 9890014670 | Email: Dmsr_sp@rediffmail.com', 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80', 'https://dmsr.edu.in', 5),
(6, 'नेहरू विद्यालय तथा विज्ञान कनिष्ठ महाविद्यालय, चंद्रपूर', 'School & Science Junior College', 'High school and junior college with well-equipped laboratories. Headmaster: श्री. प्रविण धोटे | Contact: 9822722898 | Email: nvchandrapur@gmail.com', 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=800&q=80', '#', 6),
(7, 'आदर्श किसान विद्यालय, तथा कनिष्ठ महाविद्यालय नारंडा, ता. कोरपना जि. चंद्रपूर', 'School & Junior College', 'Secondary and higher secondary education in Korpana taluka. Headmaster: श्री. अविनाश चुरमुडे | Contact: 9850697345 | Email: akvnaranda@gmail.com', 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=800&q=80', '#', 7),
(8, 'श्री साईनाथ विद्यालय, कढोली ता. राजुरा जि. चंद्रपूर', 'School', 'Foundational and secondary schooling founded in 1969. Headmistress: कु. ईंरगा आवळे | Contact: 9975026447 | Email: shrisainathvidyalaya1969@gmail.com', 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80', '#', 8),
(9, 'सरस्वती विद्यालय, तथा कनिष्ठ महाविद्यालय, वढोली, ता. गोंडपिपरी जि. चंद्रपूर', 'School & Junior College', 'Secondary and junior college education in Gondpipri. Headmaster: श्री. रंगय्य निनारनेवार | Contact: 9923180310 | Email: saraswatividyalayawadholi@gmail.com', 'https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&w=800&q=80', '#', 9),
(10, 'गुरुनानक विद्यालय, विरूर (स्टे) ता. राजुरा जि. चंद्रपूर', 'School', 'Rural school education at Virur Station. Headmaster: श्री. पांडुरंग मधुकर धानोरकर | Contact: 8788531126 | Email: Gurunanakvidayalya6@gmail.com', 'https://images.unsplash.com/photo-1524178232363-1fb2b075b655?auto=format&fit=crop&w=800&q=80', '#', 10),
(11, 'इंदिरा विद्यालय तथा कनिष्ठ महाविद्यालय, वरुड (रोड) ता. राजुरा जि. चंद्रपूर', 'School & Junior College', 'Secondary and junior college campus at Warur Road. Headmistress: सौ. कुंदा लोकेश मडावी | Contact: 9922549197 | Email: indiravidyalayawarur@gmail.com', 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80', '#', 11);

-- 6. CAREERS (Total: 5 openings)
INSERT INTO `careers` (`id`, `title`, `department`, `location`, `type`, `description`, `requirements`, `advertisementUrl`, `advertisementOriginalName`, `advertisementType`) VALUES
('h0gswhlyt', 'Administrative officer', 'Society Central Office', 'Chandrapur', 'Full Time', 'Managing administration and institutional liaisons across Sarvodaya Shikshan Mandal institutions.', 'Graduate/Postgraduate with administrative experience.', NULL, NULL, NULL),
('e6hmv3f7p', 'Assistant Professor', 'Department of Computer Science', 'S. P. College, Chnadrapur', 'Full-Time', 'abc', 'Ph.D.', '/uploads/daf_2-1789131046404-759017.pdf', 'daf.2.pdf', 'pdf'),
('i8ylgnaml', 'Assistant Professor in Mathematics', 'Science & Mathematics Department', 'Sarvodaya Mahavidyalaya, Sindewahi', 'Full-Time', 'Requires qualified candidate for teaching undergraduate and postgraduate mathematics.', 'M.Sc. Mathematics with minimum 55% and NET/SET or Ph.D.', NULL, NULL, NULL),
('calfojjuj', 'Assistant Professor in Mechanical Engineering', 'Mechanical Engineering', 'Jaysingpur, Kolhapur', 'Full Time', 'Requires teaching experience in Thermodynamics and Fluid Mechanics.', 'M.E. / M.Tech in Mechanical Engineering with First Class.', NULL, NULL, NULL),
('jrcfpbeyo', 'Assistant Professor in Mechanical Engineering', 'Mechanical Engineering', 'Jaysingpur, Kolhapur', 'Full Time', 'Requires teaching experience in Thermodynamics and Fluid Mechanics.', 'M.E. / M.Tech in Mechanical Engineering with First Class.', NULL, NULL, NULL);

-- 7. JOB APPLICATIONS (Total: 6 applications)
INSERT INTO `job_applications` (`id`, `applicationNumber`, `careerId`, `jobTitle`, `name`, `email`, `phone`, `coverLetter`, `resumeUrl`, `resumeOriginalName`, `photoUrl`, `documentsUrl`, `details`, `status`) VALUES
('gi05bi3ny', 'SSM-2026-REC-67295', 'i8ylgnaml', 'Assistant Professor in Mathematics', 'Pooja Sharma', 'pooja.sharma@example.com', '9876543210', '', '/uploads/Pooja_Resume-1789133576609-810203.pdf', 'Pooja_Resume.pdf', NULL, NULL, '{\"id\":\"gi05bi3ny\",\"applicationNumber\":\"SSM-2026-REC-67295\",\"careerId\":\"i8ylgnaml\",\"jobTitle\":\"Assistant Professor in Mathematics\",\"institutionPreference\":\"\",\"specialization\":\"\",\"name\":\"Pooja Sharma\",\"nameMarathi\":\"\",\"fatherOrHusbandName\":\"\",\"motherName\":\"\",\"dob\":\"\",\"age\":\"\",\"gender\":\"Not Specified\",\"maritalStatus\":\"Unmarried\",\"nationality\":\"Indian\",\"domicile\":\"Yes\",\"category\":\"OBC\",\"casteValidity\":\"Not Applicable\",\"pwd\":\"No\",\"aadhaar\":\"\",\"pan\":\"\",\"email\":\"pooja.sharma@example.com\",\"phone\":\"9876543210\",\"alternatePhone\":\"\",\"address\":\"\",\"city\":\"\",\"district\":\"\",\"state\":\"Maharashtra\",\"pincode\":\"\",\"correspondenceAddress\":\"\",\"qualifications\":[],\"experience\":[],\"totalExperienceYears\":\"0\",\"currentOrganization\":\"\",\"currentDesignation\":\"\",\"publications\":\"\",\"coverLetter\":\"\",\"resumeUrl\":\"/uploads/Pooja_Resume-1789133576609-810203.pdf\",\"resumeOriginalName\":\"Pooja_Resume.pdf\",\"photoUrl\":null,\"documentsUrl\":null,\"documentsOriginalName\":null,\"status\":\"shortlisted\",\"created_at\":\"2026-09-11T13:32:56.615Z\",\"adminNotes\":\"Strong qualification in Mathematics.\",\"updated_at\":\"2026-09-11T13:33:35.250Z\"}', 'shortlisted'),
('bgosingsw', 'SSM-2026-REC-74459', '', 'General Application', '', '', '', '', NULL, NULL, NULL, NULL, '{\"id\":\"bgosingsw\",\"applicationNumber\":\"SSM-2026-REC-74459\",\"careerId\":\"\",\"jobTitle\":\"General Application\",\"institutionPreference\":\"\",\"specialization\":\"\",\"name\":\"\",\"nameMarathi\":\"\",\"fatherOrHusbandName\":\"\",\"motherName\":\"\",\"dob\":\"\",\"age\":\"\",\"gender\":\"Not Specified\",\"maritalStatus\":\"Unmarried\",\"nationality\":\"Indian\",\"domicile\":\"Yes\",\"category\":\"OPEN\",\"casteValidity\":\"Not Applicable\",\"pwd\":\"No\",\"aadhaar\":\"\",\"pan\":\"\",\"email\":\"\",\"phone\":\"\",\"alternatePhone\":\"\",\"address\":\"\",\"city\":\"\",\"district\":\"\",\"state\":\"Maharashtra\",\"pincode\":\"\",\"correspondenceAddress\":\"\",\"qualifications\":[],\"experience\":[],\"totalExperienceYears\":\"0\",\"currentOrganization\":\"\",\"currentDesignation\":\"\",\"publications\":\"\",\"coverLetter\":\"\",\"resumeUrl\":null,\"resumeOriginalName\":null,\"photoUrl\":null,\"documentsUrl\":null,\"documentsOriginalName\":null,\"status\":\"new\",\"created_at\":\"2026-09-11T13:15:28.411Z\"}', 'new'),
('cjua7pnat', 'SSM-2026-REC-87795', '', 'General Application', '', '', '', '', NULL, NULL, NULL, NULL, '{\"id\":\"cjua7pnat\",\"applicationNumber\":\"SSM-2026-REC-87795\",\"careerId\":\"\",\"jobTitle\":\"General Application\",\"institutionPreference\":\"\",\"specialization\":\"\",\"name\":\"\",\"nameMarathi\":\"\",\"fatherOrHusbandName\":\"\",\"motherName\":\"\",\"dob\":\"\",\"age\":\"\",\"gender\":\"Not Specified\",\"maritalStatus\":\"Unmarried\",\"nationality\":\"Indian\",\"domicile\":\"Yes\",\"category\":\"OPEN\",\"casteValidity\":\"Not Applicable\",\"pwd\":\"No\",\"aadhaar\":\"\",\"pan\":\"\",\"email\":\"\",\"phone\":\"\",\"alternatePhone\":\"\",\"address\":\"\",\"city\":\"\",\"district\":\"\",\"state\":\"Maharashtra\",\"pincode\":\"\",\"correspondenceAddress\":\"\",\"qualifications\":[],\"experience\":[],\"totalExperienceYears\":\"0\",\"currentOrganization\":\"\",\"currentDesignation\":\"\",\"publications\":\"\",\"coverLetter\":\"\",\"resumeUrl\":null,\"resumeOriginalName\":null,\"photoUrl\":null,\"documentsUrl\":null,\"documentsOriginalName\":null,\"status\":\"new\",\"created_at\":\"2026-09-11T13:11:10.409Z\"}', 'new'),
('j05zmi7io', 'SSM-2026-REC-51927', '', 'General Application', 'Test', '', '', '', NULL, NULL, NULL, NULL, '{\"id\":\"j05zmi7io\",\"applicationNumber\":\"SSM-2026-REC-51927\",\"careerId\":\"\",\"jobTitle\":\"General Application\",\"institutionPreference\":\"\",\"specialization\":\"\",\"name\":\"Test\",\"nameMarathi\":\"\",\"fatherOrHusbandName\":\"\",\"motherName\":\"\",\"dob\":\"\",\"age\":\"\",\"gender\":\"Not Specified\",\"maritalStatus\":\"Unmarried\",\"nationality\":\"Indian\",\"domicile\":\"Yes\",\"category\":\"OPEN\",\"casteValidity\":\"Not Applicable\",\"pwd\":\"No\",\"aadhaar\":\"\",\"pan\":\"\",\"email\":\"\",\"phone\":\"\",\"alternatePhone\":\"\",\"address\":\"\",\"city\":\"\",\"district\":\"\",\"state\":\"Maharashtra\",\"pincode\":\"\",\"correspondenceAddress\":\"\",\"qualifications\":[],\"experience\":[],\"totalExperienceYears\":\"0\",\"currentOrganization\":\"\",\"currentDesignation\":\"\",\"publications\":\"\",\"coverLetter\":\"\",\"resumeUrl\":null,\"resumeOriginalName\":null,\"photoUrl\":null,\"documentsUrl\":null,\"documentsOriginalName\":null,\"status\":\"new\",\"created_at\":\"2026-09-11T13:08:31.369Z\"}', 'new'),
('rj0kevgxe', 'SSM-2026-REC-58014', '', 'Lecturer', 'Test User', 'test@example.com', '', '', NULL, NULL, NULL, NULL, '{\"id\":\"rj0kevgxe\",\"applicationNumber\":\"SSM-2026-REC-58014\",\"careerId\":\"\",\"jobTitle\":\"Lecturer\",\"institutionPreference\":\"\",\"specialization\":\"\",\"name\":\"Test User\",\"nameMarathi\":\"\",\"fatherOrHusbandName\":\"\",\"motherName\":\"\",\"dob\":\"\",\"age\":\"\",\"gender\":\"Not Specified\",\"maritalStatus\":\"Unmarried\",\"nationality\":\"Indian\",\"domicile\":\"Yes\",\"category\":\"OPEN\",\"casteValidity\":\"Not Applicable\",\"pwd\":\"No\",\"aadhaar\":\"\",\"pan\":\"\",\"email\":\"test@example.com\",\"phone\":\"\",\"alternatePhone\":\"\",\"address\":\"\",\"city\":\"\",\"district\":\"\",\"state\":\"Maharashtra\",\"pincode\":\"\",\"correspondenceAddress\":\"\",\"qualifications\":[],\"experience\":[],\"totalExperienceYears\":\"0\",\"currentOrganization\":\"\",\"currentDesignation\":\"\",\"publications\":\"\",\"coverLetter\":\"\",\"resumeUrl\":null,\"resumeOriginalName\":null,\"photoUrl\":null,\"documentsUrl\":null,\"documentsOriginalName\":null,\"status\":\"new\",\"created_at\":\"2026-09-11T13:04:47.590Z\"}', 'new'),
('pg6evuze3', 'SSM-2026-REC-44144', '', 'General Application', '', '', '', '', NULL, NULL, NULL, NULL, '{\"id\":\"pg6evuze3\",\"applicationNumber\":\"SSM-2026-REC-44144\",\"careerId\":\"\",\"jobTitle\":\"General Application\",\"institutionPreference\":\"\",\"specialization\":\"\",\"name\":\"\",\"nameMarathi\":\"\",\"fatherOrHusbandName\":\"\",\"motherName\":\"\",\"dob\":\"\",\"age\":\"\",\"gender\":\"Not Specified\",\"maritalStatus\":\"Unmarried\",\"nationality\":\"Indian\",\"domicile\":\"Yes\",\"category\":\"OPEN\",\"casteValidity\":\"Not Applicable\",\"pwd\":\"No\",\"aadhaar\":\"\",\"pan\":\"\",\"email\":\"\",\"phone\":\"\",\"alternatePhone\":\"\",\"address\":\"\",\"city\":\"\",\"district\":\"\",\"state\":\"Maharashtra\",\"pincode\":\"\",\"correspondenceAddress\":\"\",\"qualifications\":[],\"experience\":[],\"totalExperienceYears\":\"0\",\"currentOrganization\":\"\",\"currentDesignation\":\"\",\"publications\":\"\",\"coverLetter\":\"\",\"resumeUrl\":null,\"resumeOriginalName\":null,\"photoUrl\":null,\"documentsUrl\":null,\"documentsOriginalName\":null,\"status\":\"new\",\"created_at\":\"2026-09-11T13:04:15.932Z\"}', 'new');

-- 8. INQUIRIES (Total: 3 inquiries)
INSERT INTO `inquiries` (`id`, `name`, `email`, `phone`, `program`, `message`, `status`) VALUES
(1, 'Vijay Deshpande', 'vijay.deshpande@gmail.com', '9822334455', 'Senior College Admission Enquiry (M.Sc. Chemistry)', 'Interested in post-graduate research admission details for the upcoming academic session at Sardar Patel Mahavidyalaya.', 'new'),
(2, 'Anjali Ramesh Patil', 'anjali.patil@example.com', '9422881122', 'Higher Secondary Science Stream (Junior College)', 'Please provide cutoff marks and scholarship eligibility criteria for tribal and rural students.', 'contacted'),
(1788974697921, 'Pooja Sharma', 'pooja@example.com', '9876543210', 'General Inquiry', 'Looking for admissions in B.Ed course.', 'new');

-- 9. ALUMNI REGISTRATIONS (Total: 3 distinguished alumni members)
INSERT INTO `alumni_registrations` (`id`, `fullName`, `email`, `phone`, `dob`, `gender`, `institution`, `passingYear`, `degree`, `profession`, `company`, `designation`, `location`, `linkedin`, `message`, `photoUrl`) VALUES
(1, 'Dr. Rajesh M. Sharma', 'dr.rajesh.sharma@example.com', '9822114477', '1975-06-15', 'Male', 'सरदार पटेल महाविद्यालय, चंद्रपूर (Sardar Patel Mahavidyalaya)', '1998', 'M.Sc. Chemistry (Gold Medalist)', 'Higher Education & Research', 'Rashtrasant Tukadoji Maharaj Nagpur University', 'Associate Professor & Head of Department', 'Nagpur / Chandrapur, Maharashtra', 'https://linkedin.com/in/rajesh-sharma-academic', 'Proud alumnus of Sardar Patel Mahavidyalaya. The faculty and rigorous academic atmosphere laid the strongest foundation for my doctoral and teaching career.', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'),
(2, 'Sunita R. Deshmukh', 'sunita.deshmukh@example.com', '9422003311', '1988-11-20', 'Female', 'सरदार पटेल महाविद्यालय, चंद्रपूर (Sardar Patel Mahavidyalaya)', '2012', 'Master of Computer Applications (MCA)', 'Information Technology', 'Tata Consultancy Services (TCS)', 'Lead Solutions Architect', 'Pune, Maharashtra', 'https://linkedin.com/in/sunita-deshmukh-tech', 'Grateful to the dedicated professors at SPM Computer Department who guided us from rural backgrounds into top multinational software firms.', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80'),
(3, 'Amit Vinodrao Patil', 'amit.patil.deputycollector@example.com', '9158332211', '1992-04-10', 'Male', 'सरदार पटेल महाविद्यालय, चंद्रपूर (Sardar Patel Mahavidyalaya)', '2015', 'Bachelor of Commerce (B.Com)', 'Civil Services (MPSC)', 'Government of Maharashtra', 'Deputy Collector / Sub-Divisional Magistrate (SDM)', 'Mumbai / Vidarbha, Maharashtra', 'https://linkedin.com/in/amit-patil-mpsc', 'The library, study circles, and competitive guidance atmosphere at Sarvodaya Shikshan Mandal ignited my passion for public service and MPSC success.', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80');

SET FOREIGN_KEY_CHECKS = 1;
