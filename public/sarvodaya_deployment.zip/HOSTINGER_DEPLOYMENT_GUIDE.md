# Hostinger Deployment Guide for Sarvodaya Shikshan Mandal
**Website:** `https://sarvodaya.drkrishnakaroo.com/`

---

## 📁 1. Files Prepared for Deployment

All files required for hosting on Hostinger are ready in both the root folder and the compiled `dist/` folder:

1. **`database.sql`** (in root and `dist/`):
   - Contains all **9 database tables** with `utf8mb4` Unicode charset for Marathi and English text support.
   - Includes seed data:
     - All **69 rich content blocks** (board members, president/secretary messages, mandal history, contact info, etc.)
     - All **11 educational institutions** and their contact directory
     - Active **announcements** and **events**
     - Career job openings
     - Admin login credentials
2. **`api.php`** (in root and `dist/`):
   - Production PHP backend configured with your Hostinger MySQL database credentials:
     - **Host:** `localhost`
     - **Database:** `u855611336_Sarvodaya`
     - **User:** `u855611336_Sarvodaya`
     - **Password:** `Principal@Sarvodaya123`
   - Handles all API endpoints: Authentication, Content editing, Announcements, Events, Institutions, Careers, Job applications with file uploads, Inquiries, Alumni portal, and Database backups.
3. **`.htaccess`** (in root and `dist/`):
   - Configures Apache/LiteSpeed URL rewrites so `/api/*` routes are handled by `api.php`, and React SPA client routing works smoothly on page reload.
   - Passes `HTTP_AUTHORIZATION` headers securely to PHP for admin logins.
   - Protects sensitive database backup files from direct web access.
4. **`dist/`** (Compiled frontend):
   - Contains `index.html`, `assets/`, `images/`, `uploads/`, `api.php`, `.htaccess`, and `database.sql`.

---

## 🗄️ 2. Import Database in Hostinger phpMyAdmin

1. Log in to your **Hostinger hPanel** (`hpanel.hostinger.com`).
2. Go to **Databases** > **phpMyAdmin** and click **Enter phpMyAdmin** next to `u855611336_Sarvodaya`.
3. In phpMyAdmin, click on the database name `u855611336_Sarvodaya` on the left sidebar.
4. Click on the **Import** tab in the top navigation bar.
5. Click **Choose File** (or Browse) and select `database.sql`.
6. Ensure the character set is set to **utf-8** (or utf8mb4).
7. Scroll to the bottom and click **Import** (or **Go**).
8. You will see a success message: *Import has been successfully finished, 9 queries executed / tables created.*

The following 9 tables will be present:
- `admins`
- `content_blocks`
- `announcements`
- `events`
- `institutions`
- `careers`
- `job_applications`
- `inquiries`
- `alumni_registrations`

---

## 🌐 3. Upload Files to Hostinger File Manager

1. In **Hostinger hPanel**, open **File Manager**.
2. Navigate to the directory for your domain/subdomain:
   - For `sarvodaya.drkrishnakaroo.com`, open `public_html/sarvodaya` (or the folder assigned to this subdomain in your Domains settings).
3. Upload the contents of the **`dist`** folder directly into this directory:
   - `index.html`
   - `.htaccess` *(Note: Files starting with a dot might be hidden; ensure "Show hidden files" is enabled in Hostinger File Manager)*
   - `api.php`
   - `assets/` (folder and all JS/CSS files inside)
   - `images/` (folder and all image files inside)
   - `uploads/` (folder for uploaded resumes, photos, and PDFs)
4. Right-click the **`uploads`** folder in File Manager, click **Permissions**, and ensure it has write permissions (`755` or `775`).

---

## 🔐 4. Admin Login Credentials

Once deployed, access the admin panel at:
`https://sarvodaya.drkrishnakaroo.com/admin`

You can log in with:
- **Username / Email:** `admin`
- **Password:** `admin` *(or `Pass`)*

*(Alternative master account: `admin@ssm.edu` / `password123`)*

Inside the Admin panel, you can update content, announcements, events, board member photos, job postings, download submitted resumes, and manage alumni registrations.

---

## 📱 5. Mobile Responsiveness Verification

The application is built with a responsive mobile-first architecture:
- Responsive sticky top navigation bar with toggle hamburger menu
- Compact language switcher for fast toggle on mobile screens
- Responsive cards and grids across all 11 institutions, management board, and news
- Mobile-friendly job application form and directory tables with touch-friendly scroll wrappers
